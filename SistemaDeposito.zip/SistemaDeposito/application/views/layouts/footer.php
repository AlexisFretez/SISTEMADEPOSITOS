        <footer class="main-footer">
            <div class="pull-right hidden-xs">
                <b>Version</b> 1.0.0
            </div>
            <strong>Copyright &copy; 2020 <a href="#"></a>.</strong> All rights
            reserved.
        </footer>
        </div>
        <!-- ./wrapper -->

        <!-- Highcharts -->
        <script src="<?php echo base_url(); ?>assets/template/highcharts/highcharts.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/highcharts/exporting.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/jquery-print/jquery.print.js"></script>

        <!-- Bootstrap 3.3.7 -->
        <script src="<?php echo base_url(); ?>assets/template/bootstrap/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/jquery-ui/jquery-ui.js"></script>
        <!-- Select2 -->
        <script src="<?php echo base_url(); ?>assets/template/select2/dist/js/select2.full.min.js"></script>
        <!-- SlimScroll -->
        <script src="<?php echo base_url(); ?>assets/template/jquery-slimscroll/jquery.slimscroll.min.js"></script>
        <!-- DataTables -->
        <script src="<?php echo base_url(); ?>assets/template/datatables.net/js/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>


        <script src="<?php echo base_url(); ?>assets/template/datatables.net-bs/js/dataTables.responsive.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/datatables.net-bs/js/responsive.bootstrap.min.js"></script>

        <!-- DataTables Export -->
        <script src="<?php echo base_url(); ?>assets/template/datatables-export/js/dataTables.buttons.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/datatables-export/js/buttons.flash.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/datatables-export/js/jszip.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/datatables-export/js/pdfmake.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/datatables-export/js/vfs_fonts.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/datatables-export/js/buttons.html5.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/datatables-export/js/buttons.print.min.js"></script>
        <!-- FastClick -->
        <script src="<?php echo base_url(); ?>assets/template/fastclick/lib/fastclick.js"></script>
        <!-- AdminLTE App -->
        <script src="<?php echo base_url(); ?>assets/template/dist/js/adminlte.min.js"></script>
        <!-- AdminLTE for demo purposes -->
        <script src="<?php echo base_url(); ?>assets/template/dist/js/demo.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/alertify/lib/alertify.min.js"></script>

        <script src="<?php echo base_url(); ?>assets/template/jquery/jquery-confirm.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/template/jsbarcode/JsBarcode.all.min.js"></script>
        <script>
            var base_url = "<?php echo base_url(); ?>";
        </script>
        <script src="<?php echo base_url(); ?>assets/template/backend/script.js"></script>
        </body>

        </html>