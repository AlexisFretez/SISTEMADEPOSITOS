<p><strong>Nombre:</strong> <?php echo $presentacion->nombre; ?></p>
