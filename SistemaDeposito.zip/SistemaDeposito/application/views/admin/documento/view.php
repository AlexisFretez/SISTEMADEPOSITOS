<p><strong>Nombre:</strong> <?php echo $documento->nombre; ?></p>
