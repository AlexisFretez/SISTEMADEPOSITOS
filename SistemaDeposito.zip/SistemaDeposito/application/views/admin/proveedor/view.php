<p><strong>Nombre:</strong> <?php echo $proveedor->nombre; ?></p>
<p><strong>NIT:</strong> <?php echo $proveedor->nit; ?></p>
<p><strong>Tipo de Contribuyente:</strong> <?php echo $proveedor->tipocontribuyente; ?></p>
<p><strong>Direccion:</strong> <?php echo $proveedor->direccion; ?></p>
<p><strong>Telefono:</strong> <?php echo $proveedor->telefono; ?></p>
<p><strong>Email:</strong> <?php echo $proveedor->email; ?></p>
<p><strong>Contacto:</strong> <?php echo $proveedor->contacto; ?></p>
<p><strong>Tel Contacto:</strong> <?php echo $proveedor->tel_contacto; ?></p>