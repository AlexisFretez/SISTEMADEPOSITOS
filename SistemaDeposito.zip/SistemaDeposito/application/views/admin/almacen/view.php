<p><strong>Nombre:</strong> <?php echo $almacen->nombre; ?></p>
<p><strong>Fecha Creacion:</strong> <?php echo $almacen->fecha_creacion; ?></p>
<p><strong>Ubicacion:</strong> <?php echo $almacen->descripcion; ?></p>
<p><strong>Costo:</strong> <?php echo $almacen->precio; ?></p>
<p><strong>Estado:</strong> <?php echo $almacen->estado; ?></p>