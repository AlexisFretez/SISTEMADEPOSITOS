<p><strong>Nombre:</strong> <?php echo $contribuyente->nombre; ?></p>
<p><strong>Descripcion:</strong> <?php echo $contribuyente->descripcion; ?></p>