<p><strong>Nombre:</strong> <?php echo $categoria->nombre; ?></p>
<p><strong>Descripcion:</strong> <?php echo $categoria->descripcion; ?></p>