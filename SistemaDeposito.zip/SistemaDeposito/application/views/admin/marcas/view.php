<p><strong>Nombre:</strong> <?php echo $marca->nombre; ?></p>
